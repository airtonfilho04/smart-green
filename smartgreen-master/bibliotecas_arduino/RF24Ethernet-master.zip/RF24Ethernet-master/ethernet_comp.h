#ifndef ETHERNET_COMP_H
#define ETHERNET_COMP_H

#define Ethernet RF24Ethernet
#define EthernetClient RF24Client
#define EthernetServer RF24Server
#define EthernetUDP RF24UDP

#endif
