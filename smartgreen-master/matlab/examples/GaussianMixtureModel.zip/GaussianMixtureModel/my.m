function y=my(c,x)
%y=exp(x./c);
y=c*exp(x);

